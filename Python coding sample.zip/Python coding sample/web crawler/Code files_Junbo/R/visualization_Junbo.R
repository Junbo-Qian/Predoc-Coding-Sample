library(ggplot2) 
library(extrafont)

# Data
years <- c(2020, 2021, 2022, 2023, 2024) 
papers <- c(1085, 1184, 1234, 1865, 2634)

# Create a data frame
data <- data.frame(years, papers)

# Save directory path
save_dir <- "/Users/alan/Desktop/海外申请/Coding test/EPIC-CHINA/Code files_Junbo/Result/Picture"

# Function: Plot a line and bar chart
plot_trend <- function(data) {
  ggplot(data, aes(x = years, y = papers)) + 
    geom_bar(stat = "identity", fill = "#4C72B0", alpha = 0.8) +  # Soft blue color
    geom_line(color = "#DD8452", size = 1) +  # Soft orange color
    geom_point(color = "#DD8452", size = 3) + 
    geom_text(aes(label = papers), vjust = -1, color = "#DD8452", size = 4, fontface = "bold") +  # Data point labels
    labs(title = "Trend of ICML Publications from 2020 to 2024", 
         x = "Year", 
         y = "Number of Papers") + 
    theme(
      plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
      axis.title = element_text(size = 12),
      axis.text = element_text(size = 10),
      panel.grid.major = element_line(color = "gray80", linetype = "dashed"),
      panel.grid.minor = element_blank()
    ) + 
    scale_x_continuous(breaks = data$years)  # Ensure that all years are displayed on the x-axis
}

# Function: Plot a pie chart
plot_proportion <- function(data) {
  ggplot(data, aes(x = "", y = papers, fill = as.factor(years))) + 
    geom_bar(stat = "identity", width = 1, color = "white") + 
    coord_polar("y", start = 0) + 
    labs(title = "Proportion of ICML Publications by Year (2020-2024)", 
         fill = "Year") + 
    theme(
      plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
      legend.text = element_text(size = 10),
      legend.title = element_text(size = 12)
    ) + 
    geom_text(aes(label = paste0(papers, " (", round(papers/sum(papers)*100, 1), "%)")), 
              position = position_stack(vjust = 0.5), size = 4, color = "black") + 
    scale_fill_brewer(palette = "Pastel1")  # Use soft colors
}

# Plot the line and bar chart and save it
trend_plot <- plot_trend(data)
ggsave(paste0(save_dir, "Trend_R.png"), trend_plot, width = 8, height = 5, dpi = 300, device = "png")

# Plot the pie chart and save it
proportion_plot <- plot_proportion(data)
ggsave(paste0(save_dir, "Proportion_R.png"), proportion_plot, width = 8, height = 5, dpi = 300, device = "png")
