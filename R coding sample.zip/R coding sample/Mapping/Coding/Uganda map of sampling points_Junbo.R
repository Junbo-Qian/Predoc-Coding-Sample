# Author: Junbo QIAN
# E-mail: AlanQ@stu.pku.edu.cn
# Task 1: Uganda map of sampling points
# Question 1

# 1. Initialize environment
# Load necessary R packages
library(sf)             # Spatial data processing: used for reading shapefiles and managing coordinate systems
library(dplyr)          # Data manipulation: provides pipe operator (%>%) and efficient data frame handling
library(ggplot2)        
library(classInt)       # Classification algorithm: provides Jenks natural breaks classification method
library(RColorBrewer)   

# 2. File path configuration
# Raw data paths
shapefile <- "/Users/alan/Desktop/海外申请/Coding test/UCDavis/SPIA Pre-doc Assessment_Data/Problem 1 - Uganda map of sampling points/Uganda Districts Shapefiles 2020/Uganda_Districts-2020---136-wgs84.shp"
csv_production <- "/Users/alan/Desktop/海外申请/Coding test/UCDavis/SPIA Pre-doc Assessment_Data/Problem 1 - Uganda map of sampling points/Production.csv"
csv_survey <- "/Users/alan/Desktop/海外申请/Coding test/UCDavis/SPIA Pre-doc Assessment_Data/Problem 1 - Uganda map of sampling points/Survey Points.csv"

# Output directories
output_dir1 <- "/Users/alan/Desktop/海外申请/Coding test/UCDavis/Result_Junbo/Task1_Junbo/Q1"
output_dir2 <- "/Users/alan/Desktop/海外申请/Coding test/UCDavis/Result_Junbo/Task1_Junbo/Q2"

# 3. Data loading and preprocessing
# Read and preprocess administrative boundaries
ug_shp <- st_read(shapefile) %>%  # Read shapefile
  rename(District = d)            # Standardize variable name for better readability

# Read maize production data
prod_data <- read.csv(csv_production) %>% 
  rename(District = d, Production = production)  # Standardize variable names

# Merge spatial data with production attribute data
ug_data <- left_join(ug_shp, prod_data, by = "District") 

# Production classification using Jenks natural breaks
# Calculate Jenks natural breaks (5 classes)
breaks <- classIntervals(
  ug_data$Production, 
  n = 5,               # Number of classes
  style = "jenks"      # Use Jenks optimal classification algorithm
)$brks

# Create binned factor variable
ug_data$prod_bin <- cut(
  ug_data$Production,
  breaks = breaks,
  include.lowest = TRUE,  # Include the minimum value
  labels = FALSE          # Use numeric labels first
)

# Generate bin labels
bin_labels <- sapply(1:(length(breaks)-1), function(i) {
  paste0(round(breaks[i]), "–", round(breaks[i+1]), " tons")
})

# Convert to ordered factor
ug_data$prod_bin <- factor(
  ug_data$prod_bin,
  levels = 1:5,
  labels = bin_labels
)

# 5. Maize production heatmap
# Create base heatmap
p1 <- ggplot(ug_data) +
  # Administrative layer: fill color corresponds to production bins
  geom_sf(
    aes(fill = prod_bin), 
    color = "white",   # Border color of administrative units
    size = 0.1         # Border line thickness
  ) +
  # Use YlGn (yellow-green gradient)
  scale_fill_brewer(
    palette = "YlGn", 
    name = "Maize Production (tons)",
    guide = guide_legend(reverse = FALSE)  
  ) +
  # Keep geographic coordinate ratio
  coord_sf() +
  theme_minimal() +
  # Chart metadata
  labs(
    title = "Uganda Maize Production by District (2020)",
    subtitle = "Classification using Jenks natural breaks method",
    caption = "Data Sources:\n- Uganda Districts Shapefiles 2020\n- Production.csv"
  ) +
  # Adjust legend position
  theme(
    legend.position = "right",
    plot.title = element_text(face = "bold", size = 14),
    plot.caption = element_text(hjust = 0, color = "gray40")
  )
print(p1)

# Save the heatmap
ggsave(
  file.path(output_dir1, "uganda_maize_heatmap.png"),
  plot = p1,
  width = 10,      
  height = 8,       
  dpi = 300,        
  bg = "white"      
)

# Question 2

# Read and convert survey point data
survey_points <- read.csv(csv_survey)

# Convert to spatial object
survey_sf <- st_as_sf(
  survey_points,
  coords = c("longitude", "latitude"),  # Specify coordinate columns
  crs = 4326                           # EPSG:4326 (WGS84)
)

# Overlay survey points on heatmap
p2 <- p1 +
  # Add survey points layer
  geom_sf(
    data = survey_sf,
    aes(color = type),    # Color by survey type
    size = 1.0,           # Point size
    alpha = 0.8           # Transparency
  ) +
  # Use Set1 color palette (high contrast)
  scale_color_brewer(
    palette = "Set1",
    name = "Survey Type"
  ) +
  guides(
    fill = guide_legend(order = 1),  
    color = guide_legend(order = 2)  
  ) +
  labs(
    title = "Maize Production with Survey Locations",
    subtitle = "Point colors correspond to different groups"
  )

print(p2)

# Save the combined map
ggsave(
  file.path(output_dir2, "uganda_maize_heatmap_sampling.png"),
  plot = p2,
  width = 10,
  height = 8,
  dpi = 300,
  bg = "white"
)
